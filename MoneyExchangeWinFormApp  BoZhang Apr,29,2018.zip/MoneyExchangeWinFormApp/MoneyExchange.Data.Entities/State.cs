﻿namespace MoneyExchange.Data.Entities
{
    public enum State
    {
        Loaded,
        Adding,
        Editing,
        Saved,
        Deleted,
        Browsing
    }
}
