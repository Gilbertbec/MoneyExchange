﻿namespace MoneyExchange.Data.Entities
{
    public enum FileType
    {
        Text,
        Xml,
        Csv
    }
}
