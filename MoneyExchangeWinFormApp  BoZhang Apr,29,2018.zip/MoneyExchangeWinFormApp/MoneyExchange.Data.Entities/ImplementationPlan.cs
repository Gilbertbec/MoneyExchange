﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyExchange.Data.Entities
{
    public enum ImplementationPlan
    {
        ImplementationPlanByArray,
        ImplementationPlanByList
    }
}
